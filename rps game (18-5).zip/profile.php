<?php
session_start();
include 'db.php';

if (!isset($_SESSION['player_id'])) {
    header("Location: login_page.html");
    exit();
}

$id = $_SESSION['player_id'];
$query = mysqli_query($conn, "SELECT * FROM players WHERE player_id = '$id'");
$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Player Profile - RPS Arena</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;500&display=swap" rel="stylesheet">
  
  <style>
    body {
      background: radial-gradient(circle at center, #1a1a2e 0%, #16213e 100%);
      color: #ffffff;
      font-family: 'Inter', sans-serif;
      min-height: 100vh;
    }

    h5, h3, .navbar-brand, .player-name, .mmr-value, th {
      font-family: 'Orbitron', sans-serif;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .navbar {
      background: rgba(22, 33, 62, 0.95) !important;
      border-bottom: 2px solid #0f3460;
    }

    .nav-link { color: #fff !important; opacity: 0.7; }
    .nav-link.active { color: #00d2ff !important; opacity: 1; text-shadow: 0 0 10px #00d2ff; }

    .profile-card, .history-card {
      background: rgba(255, 255, 255, 0.05);
      backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      padding: 2.5rem;
      box-shadow: 0 20px 40px rgba(0,0,0,0.6);
      position: relative;
      overflow: hidden;
      margin-bottom: 30px;
    }

    .profile-card::before, .history-card::before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: linear-gradient(90deg, #00d2ff, #e94560);
    }

    .avatar-circle {
      width: 100px; height: 100px;
      background: linear-gradient(45deg, #0f3460, #16213e);
      border: 3px solid #00d2ff;
      border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      margin: 0 auto 20px;
      font-size: 2.5rem; color: #00d2ff;
      text-shadow: 0 0 15px rgba(0, 210, 255, 0.5);
    }

    .info-group {
      background: rgba(0, 0, 0, 0.2);
      padding: 15px; border-radius: 12px;
      margin-bottom: 15px; border-left: 3px solid #3a7bd5;
    }

    .label-text { color: #00d2ff; font-size: 0.75rem; font-weight: bold; text-transform: uppercase; display: block; }
    .mmr-value { color: #e94560; font-size: 1.8rem; }
    
    /* Table Styling */
    .table { color: #fff; margin-top: 20px; }
    .table-hover tbody tr:hover { background: rgba(0, 210, 255, 0.1); }
    .status-win { color: #28a745; font-weight: bold; }
    .status-loss { color: #e94560; font-weight: bold; }
    .status-draw { color: #ffc107; font-weight: bold; }

    .btn-logout {
      background: transparent; border: 2px solid #e94560; color: #e94560;
      font-family: 'Orbitron'; transition: all 0.3s;
    }
    .btn-logout:hover { background: #e94560; color: white; }
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark px-4 py-3">
    <a class="navbar-brand text-info" href="#">RPS ARENA</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="home.php">Dashboard</a></li>
        <li class="nav-item"><a class="nav-link active" href="profile.php">Profile</a></li>
      </ul>
    </div>
  </nav>

  <div class="container mt-5">
    <div class="row">
      <div class="col-lg-4">
        <div class="profile-card">
          <div class="avatar-circle">
            <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
          </div>
          <h5 class="text-center mb-4">Player Dossier</h5>
          <div class="info-group">
            <span class="label-text">Codename</span>
            <p class="mb-0"><?php echo $user['username']; ?></p>
          </div>
          <div class="info-group" style="border-left-color: #e94560; background: rgba(233, 69, 96, 0.1);">
            <span class="label-text">Combat Rating (MMR)</span>
            <p class="mmr-value mb-0"><?php echo $user['mmr']; ?></p>
          </div>
          <p class="text-center opacity-50 small mt-4">
            OPERATIVE SINCE: <?php echo strtoupper(date('d M Y', strtotime($user['created_at']))); ?>
          </p>
          <a href="logout.php" class="btn btn-logout w-100 py-2 mt-2">Terminate Session</a>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="history-card">
          <h3 class="text-info mb-4">Recent Combat Logs</h3>
          <div class="table-responsive">
            <table class="table table-dark table-borderless table-hover">
              <thead>
                <tr class="border-bottom border-secondary">
                  <th>Timestamp</th>
                  <th>Outcome</th>
                  <th>Rating Δ</th>
                  <th>Final MMR</th>
                </tr>
              </thead>
              <tbody>
                <?php
                // Query untuk menarik sejarah perlawanan (Tugasan #70)
                $history_sql = "SELECT * FROM match_history WHERE player_id = '$id' ORDER BY played_at DESC LIMIT 10";
                $history_res = mysqli_query($conn, $history_sql);

                if (mysqli_num_rows($history_res) > 0) {
                    while($row = mysqli_fetch_assoc($history_res)) {
                        $res_type = strtolower($row['result']);
                        $class = "status-" . $res_type;
                        $change_prefix = ($row['change_amount'] > 0) ? "+" : "";
                        
                        echo "<tr>
                                <td class='opacity-75'>" . date('d M, H:i', strtotime($row['played_at'])) . "</td>
                                <td><span class='$class'>" . strtoupper($res_type) . "</span></td>
                                <td class='$class'>" . $change_prefix . $row['change_amount'] . "</td>
                                <td>" . $row['mmr_after'] . "</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center opacity-50 py-4'>No battle data recorded.</td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>