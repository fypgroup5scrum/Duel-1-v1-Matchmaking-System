<?php
session_start();
include 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['player_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Sesi tamat']);
    exit;
}

$player_id = $_SESSION['player_id'];
$match_id = $_POST['match_id'] ?? '';
$move = $_POST['move'] ?? '';

$res = mysqli_query($conn, "SELECT * FROM matches WHERE match_id = '$match_id'");
$match = mysqli_fetch_assoc($res);

if (!$match) {
    echo json_encode(['status' => 'error']);
    exit;
}

// 1. Simpan pilihan pemain jika bukan sekadar menyemak (check)
if ($move !== 'check' && !empty($move)) {
    $column = ($player_id == $match['player1_id']) ? 'player1_move' : 'player2_move';
    mysqli_query($conn, "UPDATE matches SET $column = '$move' WHERE match_id = '$match_id'");
}

// 2. Ambil data perlawanan terkini selepas pilihan dibuat
$res_update = mysqli_query($conn, "SELECT * FROM matches WHERE match_id = '$match_id'");
$curr = mysqli_fetch_assoc($res_update);

// 3. Jika kedua-dua pemain sudah memilih (Tugasan #75)
if (!empty($curr['player1_move']) && !empty($curr['player2_move'])) {
    $p1_move = $curr['player1_move'];
    $p2_move = $curr['player2_move'];
    $p1_id = $curr['player1_id'];
    $p2_id = $curr['player2_id'];

    if ($curr['result'] === 'pending') {
        // Ambil MMR lama untuk pengiraan (Tugasan #61)
        $p1_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT mmr FROM players WHERE player_id = '$p1_id'"));
        $p2_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT mmr FROM players WHERE player_id = '$p2_id'"));
        $p1_old_mmr = $p1_data['mmr'];
        $p2_old_mmr = $p2_data['mmr'];

        $winner_id = null;
        $result_label = 'draw';
        $p1_change = 0;
        $p2_change = 0;

        // Tentukan pemenang (Tugasan #63)
        if ($p1_move !== $p2_move) {
            if (($p1_move == 'rock' && $p2_move == 'scissors') || 
                ($p1_move == 'paper' && $p2_move == 'rock') || 
                ($p1_move == 'scissors' && $p2_move == 'paper')) {
                $winner_id = $p1_id;
                $result_label = 'player1';
                $p1_change = 25; $p2_change = -25;
            } else {
                $winner_id = $p2_id;
                $result_label = 'player2';
                $p1_change = -25; $p2_change = 25;
            }
        }

        // Kemaskini MMR dalam pangkalan data (Tugasan #64)
        mysqli_query($conn, "UPDATE players SET mmr = mmr + $p1_change, skill_level = skill_level + $p1_change WHERE player_id = '$p1_id'");
        mysqli_query($conn, "UPDATE players SET mmr = mmr + $p2_change, skill_level = skill_level + $p2_change WHERE player_id = '$p2_id'");

        // Simpan ke Match History (Tugasan #67 & #68)
        $res_p1 = ($p1_change > 0) ? 'win' : (($p1_change < 0) ? 'loss' : 'draw');
        $res_p2 = ($p2_change > 0) ? 'win' : (($p2_change < 0) ? 'loss' : 'draw');

        mysqli_query($conn, "INSERT INTO match_history (match_id, player_id, opponent_id, result, mmr_before, mmr_after, change_amount) 
            VALUES ('$match_id', '$p1_id', '$p2_id', '$res_p1', '$p1_old_mmr', ".($p1_old_mmr + $p1_change).", $p1_change)");
        
        mysqli_query($conn, "INSERT INTO match_history (match_id, player_id, opponent_id, result, mmr_before, mmr_after, change_amount) 
            VALUES ('$match_id', '$p2_id', '$p1_id', '$res_p2', '$p2_old_mmr', ".($p2_old_mmr + $p2_change).", $p2_change)");

        // Kemaskini status perlawanan utama
        $win_sql = ($winner_id) ? "'$winner_id'" : "NULL";
        mysqli_query($conn, "UPDATE matches SET result = '$result_label', winner_id = $win_sql WHERE match_id = '$match_id'");
    }

    // Hantar maklumat baru ke UI (Tugasan #71 & #74)
    $p_final = mysqli_fetch_assoc(mysqli_query($conn, "SELECT mmr FROM players WHERE player_id = '$player_id'"));
    echo json_encode([
        'status' => 'complete',
        'p1_move' => $p1_move,
        'p2_move' => $p2_move,
        'is_p1' => ($player_id == $p1_id),
        'new_mmr' => $p_final['mmr']
    ]);
} else {
    echo json_encode(['status' => 'waiting']);
}
?>