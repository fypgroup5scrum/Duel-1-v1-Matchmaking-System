<?php
session_start();
include 'db.php';

if (!isset($_SESSION['player_id'])) {
    die("error_session");
}

$player_id = $_SESSION['player_id'];
$action = $_POST['action'] ?? '';

function getRankCategory($points) {
    if ($points <= 500) return 'Bronze';
    if ($points <= 1200) return 'Silver';
    if ($points <= 2000) return 'Gold';
    return 'Platinum';
}

// --- 1. JOIN QUEUE ---
if ($action == 'join') {
    $res = mysqli_query($conn, "SELECT skill_level FROM players WHERE player_id = '$player_id'");
    $p = mysqli_fetch_assoc($res);
    $my_skill = $p['skill_level'];
    $my_rank = getRankCategory($my_skill);

    $sql = "REPLACE INTO queue (player_id, skill_level, rank_category, status) 
            VALUES ('$player_id', '$my_skill', '$my_rank', 'waiting')";

    echo (mysqli_query($conn, $sql)) ? "searching" : "error";
    exit;
}

// --- 2. CHECK STATUS ---
if ($action == 'check_status') {

    // ALWAYS check for an existing pending match first — this runs for BOTH players
    $res_assigned = mysqli_query($conn, "SELECT match_id FROM matches 
                   WHERE (player1_id = '$player_id' OR player2_id = '$player_id') 
                   AND result = 'pending' 
                   AND player1_move IS NULL 
                   AND player2_move IS NULL
                   ORDER BY match_date DESC LIMIT 1");

    if (mysqli_num_rows($res_assigned) > 0) {
        $m = mysqli_fetch_assoc($res_assigned);
        echo "match_found:" . $m['match_id'];
        exit;
    }

    // Check if in queue
    $my_q = mysqli_query($conn, "SELECT skill_level, rank_category, status FROM queue WHERE player_id = '$player_id'");
    if (mysqli_num_rows($my_q) == 0) {
        echo "still_waiting";
        exit;
    }

    $my_info = mysqli_fetch_assoc($my_q);

    // If already matched, just wait — the match row will appear on next poll
    if ($my_info['status'] == 'matched') {
        echo "still_waiting";
        exit;
    }

    $my_skill = $my_info['skill_level'];
    $my_rank = $my_info['rank_category'];

    // Try to atomically claim an opponent
    $result = mysqli_query($conn, "SELECT player_id FROM queue 
                      WHERE player_id != '$player_id' 
                      AND status = 'waiting' 
                      AND rank_category = '$my_rank' 
                      AND ABS(skill_level - $my_skill) <= 500 
                      ORDER BY joined_at ASC LIMIT 1");

    if (mysqli_num_rows($result) == 0) {
        echo "still_waiting";
        exit;
    }

    $opp = mysqli_fetch_assoc($result);
    $opp_id = $opp['player_id'];

    // Atomically mark opponent — only succeeds if they're still 'waiting'
    mysqli_query($conn, "UPDATE queue SET status = 'matched' 
                         WHERE player_id = '$opp_id' AND status = 'waiting'");

    if (mysqli_affected_rows($conn) == 0) {
        // Opponent was already claimed by someone else
        echo "still_waiting";
        exit;
    }

    // Mark self as matched
    mysqli_query($conn, "UPDATE queue SET status = 'matched' WHERE player_id = '$player_id'");

    // Create match
    mysqli_query($conn, "INSERT INTO matches (player1_id, player2_id, result) 
                         VALUES ('$player_id', '$opp_id', 'pending')");
    $match_id = mysqli_insert_id($conn);

    echo "match_found:" . $match_id;
    exit;
}

// --- 3. CANCEL ---
if ($action == 'cancel') {
    mysqli_query($conn, "DELETE FROM queue WHERE player_id = '$player_id'");
    echo (mysqli_affected_rows($conn) > 0) ? "cancelled" : "not_found";
    exit;
}
?>
