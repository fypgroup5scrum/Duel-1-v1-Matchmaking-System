<?php
session_start();
include 'db.php';

if (!isset($_SESSION['player_id'])) {
    header("Location: login_page.html");
    exit();
}

$id = $_SESSION['player_id'];
$query = mysqli_query($conn, "SELECT * FROM players WHERE player_id = '$id'");
$user = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>RPS Arena - Home</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@300;500&display=swap" rel="stylesheet">
  <style>
    body { background: radial-gradient(circle at center, #1a1a2e 0%, #16213e 100%); color: #e94560; font-family: 'Inter', sans-serif; min-height: 100vh; overflow-x: hidden; }
    h1, h3, .navbar-brand, .btn-gaming { font-family: 'Orbitron', sans-serif; text-transform: uppercase; letter-spacing: 2px; }
    .gaming-card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 20px; padding: 3rem; box-shadow: 0 15px 35px rgba(0,0,0,0.5); }
    .navbar { background: rgba(22, 33, 62, 0.95) !important; border-bottom: 2px solid #0f3460; }
    .user-welcome { color: #00d2ff; font-weight: bold; }
    .btn-gaming { padding: 15px 40px; border-radius: 50px; font-weight: bold; transition: all 0.3s ease; border: none; }
    .btn-find { background: linear-gradient(45deg, #00d2ff, #3a7bd5); color: white; box-shadow: 0 0 20px rgba(0, 210, 255, 0.4); }
    .btn-cancel { background: transparent; border: 2px solid #e94560; color: #e94560; }
    #status-badge { font-size: 1.2rem; padding: 10px 25px; border-radius: 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); }
    #timer { font-size: 4rem; color: #00d2ff; text-shadow: 0 0 20px rgba(0, 210, 255, 0.5); }
    .pulse { animation: pulse-animation 2s infinite; }
    @keyframes pulse-animation { 0% { box-shadow: 0 0 0 0px rgba(0, 210, 255, 0.4); } 100% { box-shadow: 0 0 0 20px rgba(0, 210, 255, 0); } }
  </style>
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark px-4 py-3">
    <a class="navbar-brand text-info" href="#">RPS ARENA</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
  <li class="nav-item">
    <a class="nav-link active" href="home.php">Dashboard</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="profile.php">Profile</a>
  </li>
</ul>
      <span class="navbar-text">
        PLAYER: <span class="user-welcome"><?php echo strtoupper($user['username']); ?></span> 
        <span class="badge bg-info text-dark ms-2">MMR: <?php echo $user['mmr']; ?></span>
      </span>
    </div>
  </nav>

  <div class="container d-flex align-items-center justify-content-center" style="min-height: 80vh;">
    <div class="gaming-card text-center col-lg-8">
      <h1 class="display-4 mb-2">Battle Station</h1>
      <p class="text-white-50 mb-5">Dominate the leaderboard and claim your glory.</p>

      <div id="status-box" class="mb-4">
        <span id="status-badge" class="text-white">NOT IN QUEUE</span>
      </div>

      <div id="timer-box" class="mb-4" style="display:none;">
        <p class="text-info mb-0">ESTABLISHING CONNECTION...</p>
        <h1 id="timer">00:00</h1>
      </div>

      <div class="mt-5">
        <button id="find-btn" class="btn btn-gaming btn-find btn-lg" onclick="startMatchmaking()">INITIALIZE MATCH</button>
        <button id="cancel-btn" class="btn btn-gaming btn-cancel btn-lg" style="display:none;" onclick="cancelMatchmaking()">ABORT MISSION</button>
      </div>
    </div>
  </div>

  <script>
    let timerInterval = null;
    let checkMatchInterval = null;
    let seconds = 0;

    function startMatchmaking() {
      const formData = new FormData();
      formData.append('action', 'join');

      fetch('matchmaking.php', { method: 'POST', body: formData })
      .then(r => r.text())
      .then(data => {
        if (data.trim() === "searching") {
          document.getElementById('find-btn').style.display = 'none';
          document.getElementById('cancel-btn').style.display = 'inline-block';
          document.getElementById('timer-box').style.display = 'block';
          const badge = document.getElementById('status-badge');
          badge.textContent = 'SEARCHING...';
          badge.classList.add('pulse', 'text-info');

          timerInterval = setInterval(() => {
            seconds++;
            const mins = String(Math.floor(seconds/60)).padStart(2,'0');
            const secs = String(seconds%60).padStart(2,'0');
            document.getElementById('timer').textContent = `${mins}:${secs}`;
          }, 1000);

          checkMatchInterval = setInterval(checkStatus, 3000);
        }
      });
    }

    function checkStatus() {
      const formData = new FormData();
      formData.append('action', 'check_status');

      fetch('matchmaking.php', { method: 'POST', body: formData })
      .then(r => r.text())
      .then(data => {
        if (data.includes("match_found")) {
          const matchId = data.split(":")[1];
          clearInterval(timerInterval);
          clearInterval(checkMatchInterval);

          document.getElementById('status-badge').textContent = 'TARGET LOCKED!';
          document.getElementById('status-badge').className = 'text-success fw-bold';
          
          setTimeout(() => {
            window.location.href = "match.php?match_id=" + matchId;
          }, 1500);
        }
      });
    }

    function cancelMatchmaking() {
      const formData = new FormData();
      formData.append('action', 'cancel');
      fetch('matchmaking.php', { method: 'POST', body: formData }).then(() => location.reload());
    }
  </script>
</body>
</html>