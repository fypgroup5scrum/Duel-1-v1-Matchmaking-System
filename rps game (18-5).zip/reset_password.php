<?php
session_start();
include 'db.php';

// Sekuriti: Kalau belum verify, tendang keluar
if (!isset($_SESSION['code_verified']) || !isset($_SESSION['reset_email'])) {
    header("Location: forgot_password.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_SESSION['reset_email'];
    $new_pass = password_hash($_POST['password'], PASSWORD_BCRYPT);
    
    // UPDATE password dan RESET kolum kod supaya tidak boleh guna lagi
    $update = mysqli_query($conn, "UPDATE players SET password = '$new_pass', reset_code = NULL, code_expiry = NULL WHERE email = '$email'");

    if ($update) {
        // Clear semua session reset
        unset($_SESSION['reset_email']);
        unset($_SESSION['code_verified']);
        echo "<script>alert('Password Berjaya Dikemaskini! Sila Login Semula.'); window.location.href='login_page.html';</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>New Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background: #1a1a2e; color: white; display: flex; align-items: center; justify-content: center; height: 100vh; }</style>
</head>
<body>
    <div class="card p-4 bg-dark border-info" style="width: 350px;">
        <h4 class="text-info mb-3 text-center">SET NEW PASSWORD</h4>
        <form method="POST">
            <input type="password" name="password" class="form-control mb-3" placeholder="Min 6 characters" minlength="6" required>
            <button type="submit" class="btn btn-info w-100 fw-bold">UPDATE NOW</button>
        </form>
    </div>
</body>
</html>